# ELiS 26 — Instalação e uso

Fonte para a escrita ELiS (Escrita das Línguas de Sinais).
Versão 2.004 · Plau · https://plau.design


## O que tem nesta pasta

Quatro estilos, cada um em dois formatos:

    ELiS26-Regular.ttf       ELiS26-Regular.woff2
    ELiS26-Italic.ttf        ELiS26-Italic.woff2
    ELiS26-Bold.ttf          ELiS26-Bold.woff2
    ELiS26-BoldItalic.ttf    ELiS26-BoldItalic.woff2

- **.ttf** → para instalar no computador (Windows e Mac) e usar em
  qualquer programa: Word, Pages, Photoshop, InDesign, Figma etc.
- **.woff2** → só para sites. Não instale esses arquivos no computador.


## Antes de instalar

Se você já tem uma versão antiga da ELiS no computador, desinstale-a
primeiro e feche todos os programas abertos. Versões diferentes
instaladas ao mesmo tempo podem causar erros de exibição.


## Instalação no Windows (10 e 11)

1. Selecione os quatro arquivos **.ttf**.
2. Clique com o botão direito e escolha **Instalar para todos os
   usuários**.
   - No Windows 11, se a opção não aparecer, clique antes em
     **Mostrar mais opções**.
   - Se não tiver permissão de administrador, use **Instalar**.
3. Feche e abra de novo os programas em que vai usar a fonte.

Outra forma: abra **Configurações › Personalização › Fontes** e arraste
os arquivos .ttf para a área "Arrastar e soltar para instalar".

**Dica:** "Instalar para todos os usuários" evita que alguns programas
(como versões antigas do Adobe e do Office) não encontrem a fonte.

### Desinstalar no Windows

Configurações › Personalização › Fontes › procure "ELiS 26" ›
clique na família › **Desinstalar**.


## Instalação no Mac (macOS)

1. Dê dois cliques em cada arquivo **.ttf**. O app **Catálogo de
   Fontes** (Font Book) vai abrir.
2. Clique em **Instalar**.
3. Feche e abra de novo os programas em que vai usar a fonte.

Outra forma: abra o **Catálogo de Fontes** e arraste os quatro
arquivos .ttf para a janela.

Se o Catálogo de Fontes mostrar um aviso de validação, clique em
**Selecionar todas as fontes** › **Instalar marcadas**.

### Desinstalar no Mac

Catálogo de Fontes › procure "ELiS 26" › clique com o botão direito
› **Remover família**.


## Como usar

Depois de instalada, a fonte aparece nos menus como **ELiS 26**.
Os quatro estilos estão ligados entre si, então os atalhos de negrito
e itálico funcionam normalmente:

- Negrito: Ctrl+B (Windows) / Cmd+B (Mac)
- Itálico: Ctrl+I (Windows) / Cmd+I (Mac)

### Digitação

A ELiS 26 usa o teclado comum. Cada tecla produz um visografema da
escrita ELiS: digite as letras e símbolos normalmente e a fonte
desenha os sinais.

A fonte é **contextual**: ela muda a forma dos visografemas de acordo
com os vizinhos. Por exemplo, ao digitar letras maiúsculas em
sequência, a linha de base que une o grupo é desenhada sozinha, e
alguns visografemas repetidos (como **dd**, **hh** e **pp**) viram um
desenho único. Você não precisa fazer nada — basta que o programa
tenha os **recursos OpenType** ativados (veja abaixo).

Os números e a pontuação comum (. , ; : ? !) funcionam como em
qualquer fonte.

### Cuidados importantes

- **Não use espaçamento entre letras (tracking/kerning manual).** O
  espaçamento extra separa os traços que unem os visografemas.
- **Não use "Versalete" ou "Tudo em maiúsculas"** como formatação. Na
  ELiS, maiúsculas e minúsculas são visografemas diferentes —
  converter a caixa muda o texto.
- **Não use correção automática.** Desative o corretor ortográfico e a
  autocorreção no trecho em ELiS; eles podem trocar letras ou colocar
  a primeira letra em maiúscula sem você perceber.


## Ativando os recursos OpenType por programa

A maioria dos programas já ativa tudo sozinha. Se os visografemas não
estiverem se conectando, confira:

**Microsoft Word (Windows e Mac)**
Selecione o texto › Fonte (Ctrl+D / Cmd+D) › aba **Avançado** ›
marque **Usar alternativas contextuais** e em **Ligaduras** escolha
**Padrão e contextual**.

**Pages, Keynote e Numbers (Mac)**
Funciona sem configuração.

**Adobe InDesign, Illustrator e Photoshop**
Funciona sem configuração. Se precisar conferir: painel Caractere ›
menu › **OpenType** › mantenha **Alternativas contextuais** e
**Ligaduras padrão** marcados.

**Figma**
Funciona sem configuração com a fonte instalada no computador (no
navegador, instale o Figma Font Installer).

**Google Docs, Google Slides e Canva gratuito**
Não aceitam fontes instaladas no computador. Use o Word, o Pages ou
outro programa de desktop. No Canva Pro é possível enviar os arquivos
.ttf em **Marca › Fontes**.

**Bloco de Notas, TextEdit e similares**
Funcionam, mas evite o modo "texto simples" do TextEdit: use
**Formatar › Converter em Texto Formatado** para poder escolher a fonte.


## Compartilhando arquivos

- **PDF:** a fonte pode ser incorporada. Ao exportar ou imprimir em
  PDF, o texto em ELiS aparece corretamente para qualquer pessoa,
  mesmo sem a fonte instalada. É a forma mais segura de enviar
  materiais.
- **Word / Pages:** quem receber o arquivo também precisa ter a
  ELiS 26 instalada. No Word dá para incorporar a fonte no documento:
  Arquivo › Opções › Salvar › marque **Incorporar fontes no arquivo**
  (Windows; no Mac, Word › Preferências › Salvar).


## Uso em sites

Use os arquivos **.woff2**. Exemplo de CSS:

```css
@font-face {
  font-family: "ELiS 26";
  src: url("ELiS26-Regular.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "ELiS 26";
  src: url("ELiS26-Italic.woff2") format("woff2");
  font-weight: 400;
  font-style: italic;
  font-display: swap;
}
@font-face {
  font-family: "ELiS 26";
  src: url("ELiS26-Bold.woff2") format("woff2");
  font-weight: 700;
  font-style: normal;
  font-display: swap;
}
@font-face {
  font-family: "ELiS 26";
  src: url("ELiS26-BoldItalic.woff2") format("woff2");
  font-weight: 700;
  font-style: italic;
  font-display: swap;
}

.elis {
  font-family: "ELiS 26", sans-serif;
  letter-spacing: 0;           /* não altere: separa os traços */
  text-transform: none;        /* não converta maiúsculas/minúsculas */
  font-variant-ligatures: normal;
}
```

No HTML, marque o texto em ELiS para que leitores de tela e
corretores não tentem lê-lo como português:

```html
<p class="elis" lang="bzs" spellcheck="false">…</p>
```


## Problemas comuns

**A fonte não aparece no programa.**
Feche e abra o programa de novo. No Windows, reinstale com "Instalar
para todos os usuários". No Mac, confira no Catálogo de Fontes se a
fonte não está marcada como desativada (cinza).

**Os sinais aparecem soltos, sem a linha que os une.**
O programa está com os recursos OpenType desligados ou há
espaçamento entre letras aplicado. Veja "Ativando os recursos
OpenType" e zere o espaçamento.

**Aparecem letras comuns em vez dos sinais.**
O trecho está em outra fonte. Selecione o texto e escolha
**ELiS 26** de novo.

**A outra pessoa vê o texto errado.**
Ela não tem a fonte instalada. Envie em PDF ou envie esta pasta junto.

## Licença

A fonte ELiS é distribuída gratuitamente sob a SIL Open Font
License, versão 1.1. O texto completo está no arquivo OFL.txt,
nesta pasta, e há perguntas frequentes em https://openfontlicense.org.

Em resumo, você pode:
- usar a fonte de graça, inclusive em trabalhos comerciais;
- incorporá-la em documentos, PDFs, aplicativos e sites;
- redistribuí-la e modificá-la.

Você não pode:
- vender a fonte sozinha;
- distribuir versões modificadas com o nome "ELiS", que é reservado;
- distribuir versões modificadas sob outra licença.

O sistema ELiS – Escrita das Línguas de Sinais foi criado por
Mariângela Estelita Barros. A fonte foi desenvolvida pela Plau.

## Contato

Plau — https://plau.design
